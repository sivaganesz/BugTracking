// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
// import App from './customer';
// import Manager from './manager';
// import Tester from './tester';
// import reportWebVitals from './reportWebVitals';
// import { BrowserRouter } from 'react-router-dom';

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <BrowserRouter>
//   {/* {
//     role==="manager"?<Manager/>:role==="tester"?<Tester/>:<Customer/>
//   } */}
//     {/* <App/> */}
//     <Manager/>
//     {/* <Tester/>  */}
//   </BrowserRouter>
// );

// // If you want to start measuring performance in your app, pass a function
// // to log results (for example: reportWebVitals(console.log))
// // or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Customer from './customer';
import Manager from './manager';
import Tester from './tester';
import App from './App'
ReactDOM.render(
  <BrowserRouter>
    <Switch>
      <Route path="/manager" component={Manager} />
      <Route path="/tester" component={Tester} />
      <Route path="/customer" component={Customer} />
      <Route path="/" component={App}/>

    </Switch>
  </BrowserRouter>,
  document.getElementById('root')
);

reportWebVitals();
