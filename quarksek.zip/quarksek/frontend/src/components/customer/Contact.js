// Home.js, About.js, Contact.js

import React from 'react';

const Contact = () => {
  return (
    <div className="container mx-auto py-4">
      <h1 className="text-2xl font-bold">Contact</h1>
      <p>Welcome to the Contact page!</p>
    </div>
  );
};

export default Contact;

// Similarly, create About.js and Contact.js components
