import React, { useState } from 'react';
import { Link } from 'react-router-dom';
const Request = () => {
  const [url, setUrl] = useState('');
  const [description, setDescription] = useState('');
  const [message, setMessage] = useState('');
  const handleUrlChange = (event) => {
    setUrl(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleRequestClick = () => {
    setMessage('Sending request...');
    // Here you can add your logic to send the request
    // For example, you can use fetch or axios to send the request
  };

  return (
    <div className="container mx-auto py-12">
      <h1 className="text-2xl ml-28 font-bold">Request</h1>
     <div className='text-center'>
      <div className="my-8 ">
        <label className="block  font-bold text-lg text-gray-700">Enter the URL:</label>
        <input
        
          type="text"
          value={url}
          onChange={handleUrlChange}
          className="mt-4 p-2  border border-gray-300 rounded-md w-80"
          placeholder="Enter URL"
        />
      </div>
      <div className="my-4">
        <label className="block font-bold text-lg  text-gray-700">Credentials:</label>
        <input
          type="text"
          value={description}
          onChange={handleDescriptionChange}
          className="mt-4 p-2 border border-gray-300 rounded-md w-80"
          placeholder="Enter description"
        />
      </div>
      <Link to="/Request" className="text-white block py-2">
        <button class="bg-gray-700 hover:bg-green-600 text-white font-bold py-2 px-4 shadow-lg	 rounded mt-6" onClick={handleRequestClick}>Request</button>
</Link>
{message && <p className="mt-6 text-lg font-bold">{message}</p>}

      </div>
    </div>
  );
};

export default Request;
