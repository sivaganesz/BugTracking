// Sidebar.js

import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  return (
    <div className="bg-blue-300 h-screen w-64 fixed left-0 top-0 pt-12 border border-red-800 border-2">
        <div className="p-4">
        <h1 className="text-white text-lg font-bold">Sidebar</h1>
        <ul className="mt-4">
          <li>
            <Link to="/" className="text-white block py-2">Home</Link>
          </li>
          <li>
            <Link to="/about" className="text-white block py-2">About</Link>
          </li>
          <li>
            <Link to="/contact" className="text-white block py-2">Contact</Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
