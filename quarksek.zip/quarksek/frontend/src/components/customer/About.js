import React, { useState } from 'react';

function About() {
  const [showNotification, setShowNotification] = useState(false);

  const handleButtonClick = () => {
    setShowNotification(true);

    setTimeout(() => {
      setShowNotification(false);
    }, 3000);
  };

  return (
    <div>
      <button onClick={handleButtonClick}>Show Notification</button>
      {showNotification && (
        <div
          style={{
            position: 'fixed',
            top: '100px',
            right: '100px',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            color: '#fff',
            padding: '10px',
            borderRadius: '5px',
            zIndex: 9999,
          }}
        >
          This is a notification!
        </div>
      )}
    </div>
  );
}

export default About;
