import React, { useState } from 'react';

const BugRaiseForm = () => {
  const [bugraise, setBugraise] = useState('');
  const [summary, setSummary] = useState('');
  const [severity, setSeverity] = useState('');

  const handleSeverityChange = (event) => {
    setSeverity(event.target.value);
  };

  const getSeverityColor = () => {
    switch (severity) {
      case 'High':
        return 'font-bold text-xl text-red-600'; // Green color for High severity
      case 'Medium':
        return 'font-bold text-xl  text-yellow-500'; // Yellow color for Medium severity
      case 'Low':
        return 'font-bold text-xl text-green-600'; // Red color for Low severity
      default:
        return ''; // Default color
    }
  };

  return (
    <div>
      <h1 className="text-3xl ml-20 mt-10 underline underline-offset-8 font-bold text-blue-900">
        BUGREISE
      </h1>
      <div className="max-w-md mx-auto p-6 bg-white rounded-lg mt-8 border border-red-700 shadow-xl">
        <h2 className="text-2xl font-semibold mb-4">Bugraise Form</h2>
        <div className="mb-4">
          <label className="block text-gray-700 ">Bugraise:</label>
          <input
            type="text"
            className="mt-1 p-2 w-full border rounded"
            placeholder="bugraise"
            value={bugraise}
            onChange={(e) => setBugraise(e.target.value)}
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Summary:</label>
          <input
            type="text"
            className="mt-1 p-2 w-full border rounded"
            placeholder="summary"
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Severity:</label>
          <div>
            <label className="inline-flex items-center mt-2">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-indigo-600"
                value="High"
                checked={severity === 'High'}
                onChange={handleSeverityChange}
                required
              />
              <span className={`ml-2`}>High</span>
            </label>
            <label className="inline-flex items-center mt-2 ml-2">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-indigo-600"
                value="Medium"
                checked={severity === 'Medium'}
                onChange={handleSeverityChange}
              />
              <span className={`ml-2`}>Medium</span>
            </label>
            <label className="inline-flex items-center mt-2 ml-2">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-indigo-600"
                value="Low"
                checked={severity === 'Low'}
                onChange={handleSeverityChange}
              />
              <span className={`ml-2 `}>Low</span>
            </label>
          </div>
        </div>
        {severity && (
          <div>
            <label className="block text-gray-700">Selected Severity:</label>
            <span className={`ml-2 ${getSeverityColor()}`}>{severity}</span>
          </div>
        )}
        <div className='flex'>
        <button className="bg-blue-900 text-white px-4 py-1 font-semibold rounded mt-5">SEND</button>
        <section className='mt-5 ml-6'><h1 className='bg-red-100 px-2 py-1 rounded' >choose
        <select className='ml-4'>
        <option>---------</option>
        <option className='text-yellow-600 font-bold'>Need More Info</option>
        <option className='text-blue-600 font-bold'>Fixed</option>
        <option className='text-gray-600 font-bold'>Not Reproducible</option>
        <option className='text-red-600 font-bold'>  Invaild</option>
        <option className='text-green-600 font-bold'>Completed</option>
        </select></h1></section>
        </div>
      </div>
    </div>
  );
};

export default BugRaiseForm;
