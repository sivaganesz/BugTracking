// import React from 'react';
// import { Link } from 'react-router-dom/cjs/react-router-dom.min';

// const CustomerReq = () => {
//   // Sample array of customer messages
//   const customerMessages = [
//     "1 ) Customer message ",
//     "2 ) Customer message ",
//     "3 ) Customer message ",
//   ];

//   return (
//     <div className="container mx-auto py-4">
//       <div className="ml-8">
//         <h1 className="text-2xl font-bold"> customer Request</h1>
//         <div className="mt-4">
//         {/* <Link to="/reqcustomer" className="text-white block py-2"> */}
//           {customerMessages.map((message, index) => (
//             <p key={index} className="text-lg">{message}<button class="bg-blue-700 hover:bg-green-600 text-white px-6 rounded ml-10 mt-4"><Link to="/contact" className="text-white block py-2">status
//             </Link></button></p>
//           ))}
//           {/* </Link> */}
//         </div>
//       </div>
//     </div>  
//   );
// }; 

// export default CustomerReq;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
// Assuming Notification component is created

const CustomerReq = () => {
  const [customerMessages, setCustomerMessages] = useState([
    "1) Customer message ",
    "2) Customer message ",
    "3) Customer message ",
  ]);

  const addCustomerMessage = (message) => {
    setCustomerMessages(prevMessages => [...prevMessages, message]);
    // Trigger notification here
  };

  return (
    <div className="container mx-auto py-4">
      <div className="ml-8">
        <h1 className="text-2xl font-bold">Customer Request</h1>
        <div className="mt-4">
          {customerMessages.map((message, index) => (
            <p key={index} className="text-lg">
              {message}
              <button className="bg-blue-700 hover:bg-green-600 text-white px-6 rounded ml-10 mt-4">
                <Link to="/contact" className="text-white block py-2">Status</Link>
              </button>
            </p>
          ))}
        </div>
      </div>
    </div>  
  );
}; 

export default CustomerReq;
