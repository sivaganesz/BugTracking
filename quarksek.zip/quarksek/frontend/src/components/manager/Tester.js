import React, { useState } from 'react';

const Tester = () => {
  const [testers] = useState([
    { id: 1, message: "1) Tester", status: "under work" },
    { id: 2, message: "2) Tester", status: "under work" },
    { id: 3, message: "3) Tester", status: "under work" },
    { id: 4, message: "4) Tester", status: "available" }
  ]);

  let workingCount = 0;
  let availableCount = 0;

  return (
    <div className="container mx-auto py-4">
      <div className="ml-8">
        <h1 className="text-2xl font-bold">Available Tester</h1>
        <table className="mt-4 w-1/2">
          <thead>
            <tr>
              <th className="px-4 py-2">Tester</th>
              <th className="px-4 py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {testers.map((tester) => {
              if (tester.status === "under work") {
                workingCount++;
              } else if (tester.status === "available") {
                availableCount++;
              }

              return (
                <tr key={tester.id}>
                  <td className="border px-4 py-2">{tester.message}</td>
                  <td className="border px-4 py-2">
                    {tester.status === "under work" ? (
                      <button className="bg-orange-400 hover:bg-green-600 text-white py-1 px-3 rounded">Under Work</button>
                    ) : (
                      <button className="bg-green-700 hover:bg-green-600 text-white py-1 px-3 rounded">Available</button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <div className="mt-4">
          <br/>
          <p>Total number of working workers: {workingCount}</p>
          <p>Total number of available workers: {availableCount}</p>
        </div>
      </div>
    </div>  
  );
}; 

export default Tester;
