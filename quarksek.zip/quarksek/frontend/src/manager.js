// // App.js
// import React from 'react';
// import { BrowserRouter as Router, Route,Link} from 'react-router-dom'; // Import BrowserRouter and Route
// import Home from './components/page1'; // Correct component names
// import About from './components/page2'; // Correct component names
// import Sidebar  from './components/Sidebar';
// import { BrowserRouter } from 'react-router-dom/cjs/react-router-dom.min';

// function App() {
//   return (
//     <div>
//       <BrowserRouter>
//       <section className="bg-purple-200 rounded p-6">
//         <div >
//           <ul className="flex">
//           <li ><Link to="/page1"><button>home</button></Link></li>
//           <li className="ml-10"><Link to="/page2"><button>about</button></Link></li>

//           </ul>
//         </div>
//       </section>
//       <section className="bg-blue-200 fixed w-48 h-full ">
//         <div >
//           <ul className="flex">
//           <li ><Link to="/page1"><button>home</button></Link></li>
//           <li className="ml-10"><Link to="/page2"><button>about</button></Link></li>

//           </ul>
//         </div>
//       </section>
      



      
//         <Route path="/side" component={Sidebar}/>
//         <Route path="/page1" component={Home} /> {/* Use component instead of elememt */}
//         <Route path="/page2" component={About} /> {/* Use component instead of elememt */}
//       </BrowserRouter>
//     </div>
//   );
// }

// export default App;


// App.js

// App.js
    
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Layout from './components/manager/Layout'; // Adjusted import path
import Tester from './components/manager/Tester'; // Adjusted import path
import CustomerReq from './components/manager/CustomerReq'; // Adjusted import path
import Contact from './components/manager/Contact'; // Adjusted import path
import Request from './components/manager/Request';
// import Cus_request from './components/customer/just';

const Manager = () => {
  return (
    <div>
      
    <Router>
      <Layout>
        <Switch>
         
          <Route path="/tester" exact component={Tester} />
          <Route path="/customerreq" component={CustomerReq} />
          <Route path="/contact" component={Contact} />
          <Route path="/Request" component={Request}/>
          {/* <Route path="/cus_request" component={Cus_request}/> */}
        </Switch>
      </Layout>
    </Router>
 
    </div>
  );
};

export default Manager;
