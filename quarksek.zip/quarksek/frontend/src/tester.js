
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Layout from './components/tester/Layout'; // Adjusted import path
// import Tester from './components/tester/Tester'; // Adjusted import path
// import CustomerReq from './components/tester/CustomerReq'; // Adjusted import path
// import Contact from './components/tester/Contact'; // Adjusted import path
import Request from './components/tester/Request';
import Home from './components/tester/Home';
import Status from './components/tester/status';
import Bugraise from'./components/tester/bugraise';


const Tester = () => {
  return (
   
    <Router>
      <Layout>
        <Switch>
     
        <Route path="/" exact component={Home}/>
        <Route path="/requesturl" component={Request}/>
        <Route path="/status" exact component={Status}/>
        <Route path="/bugraise" exact component={Bugraise}/>


        </Switch>
      </Layout>
    </Router>
 
  );
};

export default Tester ;
